import 'package:Exercicio4/myapp.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}
