import 'package:flutter/material.dart';
import 'package:exercicio_2/cadastrar_pessoa.dart';
import 'package:exercicio_2/detalhes_aniversario.dart';
import 'package:exercicio_2/listar_aniversarios.dart';
import 'package:exercicio_2/my_homepage.dart';


class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Agenda de Aniversários',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        
       initialRoute: //TODO: defina LoginPage como rota incial
        routes: {
         //TODO: Defina as rotas de navegação usando as constantes definidas dentro de cada classe
       
        }
        );
   }
}
