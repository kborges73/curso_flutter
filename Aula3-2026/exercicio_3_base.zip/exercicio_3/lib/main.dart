import 'package:exercicio2/login_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

